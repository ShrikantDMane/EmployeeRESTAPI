package com.bfl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Salary_Details_Table")
public class SalaryEntity {
    
	@Id
	@GeneratedValue
	@Column(name = "EmplId")
	private Integer EmplId;
	
	@Column(name = "Salary_Amount")
	private Integer Salary;
	
	    @OneToOne
	    @MapsId
	    @JoinColumn(name = "EmplId")
	private EmployeeEntity employeeEntity;
}
