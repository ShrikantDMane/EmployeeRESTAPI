package com.bfl.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Employee_Details_Table")
public class EmployeeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EmplId")
    private Integer EmplId;
	
	@Column(name = "Employee_Name")
	private String EmpName;
	
	@Column(name = "Employee_Address")
    private String EmpAddress;
	
	@Column(name = "Employee_MobileNo")
	private String EmpMobile;

    @OneToOne(mappedBy = "employeeEntity",cascade=CascadeType.ALL)
    @PrimaryKeyJoinColumn
    private SalaryEntity salaryentity;
}
