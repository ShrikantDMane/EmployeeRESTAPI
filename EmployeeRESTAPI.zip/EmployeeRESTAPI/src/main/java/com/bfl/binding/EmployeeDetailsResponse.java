package com.bfl.binding;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDetailsResponse {

	private Integer EmplId;

	private String EmpName;

	private String EmpAddress;

	private String EmpMobile;

	private Integer Salary;

}
