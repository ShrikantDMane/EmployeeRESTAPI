package com.bfl.rest;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bfl.binding.EmployeeDetailsResponse;
import com.bfl.service.EmployeeServiceImpl;



@RestController
public class EmployeeRestController {

	@Autowired
	private EmployeeServiceImpl esimpl;

	@GetMapping(value = "/findEmployeeDetails/{EmplId}", produces = { "application/json" })
	public ResponseEntity<EmployeeDetailsResponse> findEmployeeDetails(@PathVariable Integer EmplId) {
         
		if(EmplId==null) {
			List<EmployeeDetailsResponse> allEmployees = esimpl.getAllEmployees();
			return new ResponseEntity<EmployeeDetailsResponse>((EmployeeDetailsResponse) allEmployees, HttpStatus.FOUND);
		} else {
			EmployeeDetailsResponse findEmployeeById = esimpl.findEmployeeById(EmplId);
			return new ResponseEntity<EmployeeDetailsResponse>(findEmployeeById, HttpStatus.FOUND);
		}
		
	}
	
	
   //// 
	
	@GetMapping(value = "/findEmployeeDetails", produces = { "application/json" })
	public List<EmployeeDetailsResponse> findEmployeeDetailswhennull() {
         
		 
			List<EmployeeDetailsResponse> allEmployees = esimpl.getAllEmployees();
			return allEmployees;
		 
		}
		
	}

	
	
	

