package com.bfl.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfl.binding.EmployeeDetailsResponse;
import com.bfl.entity.EmployeeEntity;
import com.bfl.exceptions.RecordNotFoundException;
import com.bfl.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeerepository;

	@Override
	public List<EmployeeDetailsResponse> getAllEmployees() {
		List<EmployeeEntity> entitiesList = employeerepository.findAll();
		List<EmployeeDetailsResponse> employeeList = new ArrayList<>();

		entitiesList.forEach(oftheentitypresentinentitieslist -> {

			EmployeeDetailsResponse e = new EmployeeDetailsResponse();
			BeanUtils.copyProperties(oftheentitypresentinentitieslist, e);
			employeeList.add(e);
		});
		return employeeList;
	}

	@Override
	public EmployeeDetailsResponse findEmployeeById(Integer EmplId) {

		Optional<EmployeeEntity> optional = employeerepository.findById(EmplId);
		if (optional.isPresent()) {

			EmployeeEntity savedemployeeDtlsEntity = optional.get();
			EmployeeDetailsResponse response = new EmployeeDetailsResponse();
			BeanUtils.copyProperties(savedemployeeDtlsEntity, response);
			return response;
		} else {

			throw new RecordNotFoundException("No record Found "); // throwing customized exception
		}
	}

}
