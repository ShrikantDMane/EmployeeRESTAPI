package com.bfl.service;

import java.util.List;

import com.bfl.binding.EmployeeDetailsResponse;


public interface EmployeeService {

	public List<EmployeeDetailsResponse> getAllEmployees();
	
	public EmployeeDetailsResponse findEmployeeById(Integer EmplId);
	
}
