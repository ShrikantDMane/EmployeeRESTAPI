package com.bfl.employeeRESTAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
